---
alias: []
Status: #status/literature
Author: [[]]
Source: [[]]
Medium: #literature/books 
Tags: inbox
---
___
# how negative self belief affects external situations
___
_In fact, it is literally impossible to really think positively about a particular situation as long as you hold a negative concept of your “self.” And numerous experiments have shown that once the concept of self is changed, other things consistent with the new concept of self are accomplished easily and without strain._

February 18, 2022

[27](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA27)

References:

Links: [[Fleeting Notes]] , [[how negative self belief affects external situations ActionItem]]
Created: 2022-04-23 19:11