_No responsible MD would attempt to perform extensive plastic surgery without specialized knowledge and training. Just so, I feel that if changing a man’s face is going to change the inner man as well, I have a responsibility to acquire specialized knowledge in that field, also._

this is how author got into psychology

February 18, 2022

[15](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA15)

_Pasteur was not an MD. The Wright brothers were not aeronautical engineers but bicycle mechanics. Einstein, properly speaking, was not a physicist but a mathematician. Yet his findings in mathematics completely turned upside down all the pet theories in physics. Madame Curie was not an MD but a physicist, yet she made important contributions to medical science._

February 18, 2022

[17](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA17.w.0.0.0.2)