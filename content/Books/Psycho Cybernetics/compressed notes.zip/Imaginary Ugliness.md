According to this theory, persons with normal or acceptable faces should be singularly free from all psychological handicaps. They should be cheerful, happy, self-confident, free from anxiety and worry. We know only too well this is not true.

When this self-image is intact and secure, you feel good. When it is threatened, you feel anxious and insecure. When your self-image is adequate and one that you can be wholesomely proud of, you feel self-confident. You feel free to “be yourself” and to express yourself.



