Once, however, a correct or “successful response” has been accomplished, it is “remembered” for future use. The automatic mechanism then duplicates this successful response on future trials. It has “learned” how to respond successfully. It forgets its failures, and repeats the successful action without any further conscious thought—that is, as a habit.

