_Man is by nature a goal-striving being. And because man is “built that way,” he is not happy unless he is functioning as he was made to function—as a goal striver. Thus true success and true happiness not only go together but each enhances the other._

February 18, 2022

[23](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA23.w.0.0.0.2)