**

# Psycho-Cybernetics: Updated and Expanded

Maxwell Maltz

TarcherPerigee

**
# Chapters
1. [[The Self-Image - Your Key to a Better Life]]
2. [[Discovering the Success Mechanism Within You]]
3. [[Imagination - The First Key to Your Success Mechanism]]
4. [[Dehypnotize Yourself from False Beliefs]]
5. [[How to Utilize the Power of Rational Thinking]]
6. [[Relax and Let Your Success Mechanism Work for You]]
7. [[You Can Acquire the Habit of Happiness]]
8. [[Ingredients of the “Success-Type” Personality and How to Acquire Them]]
9. [[The Failure Mechanism - How to Make It Work for You Instead of Against You]]
10. [[How to Remove Emotional Scars, or How to Give Yourself an Emotional Face-Lift]]
11. [[How to Unlock Your Real Personality]]
12. [[Do-It-Yourself Tranquilizers That Bring Peace of Mind]]
13. [[How to Turn a Crisis into a Creative Opportunity]]
14. [[How to Get That Winning Feeling]]
15. [[More Years of Life and More Life in Your Years]]