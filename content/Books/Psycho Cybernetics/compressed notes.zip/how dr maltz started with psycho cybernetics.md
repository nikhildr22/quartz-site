_Instantly—and yes, I do mean instantly—I felt good. I felt happy. I felt successful. I felt like a winner. It was an odd sensation. Intellectually, it made no sense. How could I be happy now? How could I feel successful now? How could I feel like a winner now? Didn’t I have to achieve those goals in order to feel good, to be happy? And what about all the failures? Were they simply forgotten? Wasn’t I supposed to feel bad forever for not achieving everything I set out to do?_

_“There is no way to happiness. Happiness is the way.”_

February 18, 2022

[13](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA13.w.0.0.0.1)

Maltz did not work in psychology, still his contribution is tremendous
[[your domain does not matter]]
