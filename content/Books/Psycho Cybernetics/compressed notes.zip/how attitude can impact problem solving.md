_“Once a scientist attacks a problem which he knows to have an answer, his entire attitude is changed. He is already some 50 percent of his way toward that answer.”_

February 19, 2022

[48](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA48.w.0.0.0.4)