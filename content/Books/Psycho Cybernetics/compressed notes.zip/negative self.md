In fact, it is literally impossible to really think positively about a particular situation as long as you hold a negative concept of your “self.” And numerous experiments have shown that once the concept of self is changed, other things consistent with the new concept of self are accomplished easily and without strain.

[[concept of self]]