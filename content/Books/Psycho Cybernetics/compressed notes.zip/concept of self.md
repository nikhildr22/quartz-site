Prescott Lecky, one of the pioneers in self-image psychology. Lecky conceived of the personality as a “system of ideas,” all of which must seem to be consistent with one another. Ideas that are inconsistent with the system are rejected, “not believed,” and not acted on. Ideas that seem to be consistent with the system are accepted.

[[How concept of self can affect attitude]]

[[Imaginary Ugliness]]


