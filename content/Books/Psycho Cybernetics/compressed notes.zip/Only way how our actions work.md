---
aliases: 
---

you will “act like” the sort of person you conceive yourself to be. Not only this, but you literally cannot act otherwise, in spite of all your conscious efforts or willpower.

