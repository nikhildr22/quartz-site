A squirrel does not have to be taught how to gather nuts. Nor does it need to learn that it should store them for winter. 

March 7, 2022

A bird does not need to take lessons in nest-building. Nor does it need to take courses in navigation. Yet birds do navigate thousands of miles, sometimes over open sea. 

March 7, 2022 40

In short, animals have a Success Instinct. 

March 7, 2022 40 

We often overlook the fact that man, too, has a Success Instinct, much more marvelous and much more complex than that of any animal. Our Creator did not shortchange man. On the other hand, man was especially blessed in this regard. 

March 7, 2022 40 
Man, on the other hand, has something animals don’t: Creative Imagination. Thus man of all creatures is more than a creature, he is also a creator. 
March 7, 2022 41

Thus man of all creatures is more than a creature, he is also a creator.