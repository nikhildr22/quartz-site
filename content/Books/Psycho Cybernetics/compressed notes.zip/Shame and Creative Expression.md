When your idenity/image of self is an object of shame, you attempt to hide it rather than express it. Creative expression is blocked. You become hostile and hard to get along with.

[[Imaginary Ugliness]]  [[The Self-Image - Your Key to a Better Life]]
[[concept of self]]

