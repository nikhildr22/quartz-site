_But how can a person draw upon memories of past successful experiences when he has experienced only failure? 
His plight is somewhat comparable to the young man who cannot secure a job because he has no
experience, and cannot acquire experience because he cannot get a job._

February 18, 2022

[20](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA20.w.0.0.0.1)