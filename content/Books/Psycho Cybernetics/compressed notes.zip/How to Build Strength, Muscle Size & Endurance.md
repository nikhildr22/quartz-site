https://www.youtube.com/watch?v=IAnhFUUCq6c

# Dr. Andy Galpin: How to Build Strength, Muscle Size & Endurance | Huberman Lab Podcast #65


---
# Adaptations and progressive overload
principles of strength/endurance training.

1. Improving skill
2. Improving speed
3. Improving power (strength`*`Speed)
4. strength
5. hypertrophy
6. muscular endurance
7. cardiovascular
8. long duration endurance

Progressive overload
#todo/paused 

