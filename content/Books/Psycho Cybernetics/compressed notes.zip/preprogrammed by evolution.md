There is within each one of us a “life instinct,” which is forever working toward health, happiness, and all that makes for more life for the individual. This “life instinct” works for you through what I call the “Creative Mechanism” or, when used correctly, the “Success Mechanism” built into each human being.

>here the author gives examples of other animals having life instincts, mainy to gather food, mate, survival.
>And all these happen naturally, but we human can program that life instinct, as per our dreams and visions.

 Creative Mechanism within you is impersonal. It will work automatically and  impersonally to achieve goals of success and happiness, or unhappiness and failure, depending on the goals that you yourself set for it. Present it with “[[success Goals]],” and it functions as a Success Mechanism. Present it with negative goals, and it operates just as impersonally, and just as faithfully, as a Failure Mechanism.

 [[Creative mechanism]]