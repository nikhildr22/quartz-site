Like any other servo-mechanism, our Creative Mechanism works on information and data that we feed into it (our [[thoughts]], [[beliefs]], [[interpretations]]). Through our attitudes and interpretations of situations, we “describe” the problem to be worked on.

Like any other servo-mechanism, our Creative Mechanism makes use of stored information, or  “[[memory]],” in solving current problems and responding to current situations.

[[Using Creative Mechanism]]