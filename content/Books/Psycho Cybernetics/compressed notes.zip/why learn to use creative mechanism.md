_earning something about this Creative Mechanism, or automatic guidance system within you and how to use it as a Success Mechanism, rather than as a Failure Mechanism. The method itself consists in learning, practicing, and experiencing new habits of thinking, imagining, remembering, and acting in order to 
(1) develop an adequate and realistic self-image, and 
(2) use your Creative Mechanism to bring success and happiness in achieving particular goals._

February 18, 2022

[37](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA37)

# All you need is one success experince

_In order to direct your servo-mechanism toward success instead of failure, all you need is one experience that made you feel good about yourself. Remembering and then using that modest accomplishment will be instrumental in improving your self-image. You do not need a huge success experience to alter your self-image for the better. You do not need an experience that is a mirror of what you’re trying to create or accomplish. All you need is an experience like tying your shoe or learning to write your name for the first time, wherein you can say, “Yes, I’m glad I learned that skill. Yes, I remember the first day I could do it. Yes, I was happy.” This one memory, this one positive experience, no matter how long ago it took place, is all you need to begin changing the course of your life in the present._

February 18, 2022

[37](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA37.w.0.0.0.4)