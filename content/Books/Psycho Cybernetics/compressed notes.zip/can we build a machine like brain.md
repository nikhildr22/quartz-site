_But even should such a machine be built, it would lack an “operator.” A computer does not have a forebrain, nor does it have an “I.” It cannot pose problems to itself. It has no imagination and cannot set goals for itself. It cannot determine which goals are worthwhile and which are not. It has no emotions. It cannot “feel.” It works only on new data fed to it by an operator, by feedback data it secures from its own “sense organs” and from information previously stored._

February 19, 2022

[47](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA47.w.0.0.0.1)

[[How your brain is different than a computer brain]]