_Both experimental and clinical psychology have proved beyond a shadow of a doubt that the human nervous system cannot tell the difference between an actual experience and an experience imagined vividly and in detail._

February 18, 2022

[20](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA20.w.0.0.0.3)