_most of these beliefs about ourselves have unconsciously been formed from our past experiences, our successes and failures, our humiliations, our triumphs, and the way other people have reacted to us, especially in early childhood. From all these we mentally construct a “self” (or a picture of a self)._

February 18, 2022

[24](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA24.w.0.0.0.4)

![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image005.gif)

_you will “act like” the sort of person you conceive yourself to be. Not only this, but you literally cannot act otherwise, in spite of all your conscious efforts or willpower._

February 18, 2022

[25](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA25.w.0.0.0.1)

![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image005.gif)

[[how negative self belief affects external situations]]
![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image005.gif)

[[what is personality]]