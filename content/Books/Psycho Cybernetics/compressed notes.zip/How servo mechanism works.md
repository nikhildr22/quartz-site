_Like any other servo-mechanism, our Creative Mechanism works on information and data that we feed into it (our thoughts, beliefs, interpretations). Through our attitudes and interpretations of situations, we “describe” the problem to be worked on._

February 18, 2022

[36](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA36.w.0.0.0.3)

![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image008.gif)

_Like any other servo-mechanism, our Creative Mechanism makes use of stored information, or                                          “[[memory]],” in solving current problems and responding to current situations._

February 18, 2022

[36](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA36.w.0.0.0.4)

_The word “cybernetics” comes from a Greek word that means, literally, “the steersman.” Servo-mechanisms are so constructed that they                                          automatically “steer” their way to a goal, target, or “answer.”_

March 7, 2022

[42](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA42.w.0.0.0.1)

![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image011.gif)

[[is man a machine]]
![](file:///C:/Users/Nikhil/AppData/Local/Packages/oice_16_974fa576_32c1d314_646/AC/Temp/msohtmlclip1/01/clip_image011.gif)

[[two types of servo mechanism]]