**

## 1. The Self-Image: Your Key to a Better Life

  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

most of these beliefs about ourselves have unconsciously been formed from our past experiences, our successes and failures, our humiliations, our triumphs, and the way other people have reacted to us, especially in early childhood. From all these we mentally construct a “self” (or a picture of a self).

  

February 18, 2022

[24](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA24.w.0.0.0.4)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)


you will “act like” the sort of person you conceive yourself to be. Not only this, but you literally cannot act otherwise, in spite of all your conscious efforts or willpower.

  

February 18, 2022

[25](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA25.w.0.0.0.1)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

In fact, it is literally impossible to really think positively about a particular situation as long as you hold a negative concept of your “self.” And numerous experiments have shown that once the concept of self is changed, other things consistent with the new concept of self are accomplished easily and without strain.

  

February 18, 2022

[27](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA27)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

Prescott Lecky, one of the pioneers in self-image psychology. Lecky conceived of the personality as a “system of ideas,” all of which must seem to be consistent with one another. Ideas that are inconsistent with the system are rejected, “not believed,” and not acted on. Ideas that seem to be consistent with the system are accepted.

  

February 18, 2022

[27](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA27.w.0.0.0.1)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

proudly wearing his “saber scar” much as an American might wear the Medal of Honor. The duelists were the elite of college society, and a facial scar was the badge that proved you a member in good standing. To these boys, the acquisition of a horrible scar on the cheek had the same psychological effect as the eradication of the scar from the cheek of my salesman patient.

  

two kinds of attitudes observed for having a scar on the face. Its all subjective to how the individual thought about having the scar. So, if you believe/convince yourself. there's no difference, even though those are 2 extreme ends. Its all up to you.

  

February 18, 2022

[31](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA31.w.0.0.0.1)

  

  
  

  

![](https://lh4.googleusercontent.com/hQ4FB5rXT_FJywA_RPRgKX05nesBmDOS1sqDHVLcjnMcbqDSU7MhbOjg0iYLsaPdRPfSB1miLXjNS2n8IqDvaZt-PWf7g9OMzvyft5Lmt-tAun39OlvByaX63ykf4S2VWdXjCFjL)

The Mystery of Imaginary Ugliness

  

February 18, 2022

[31](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA31.w.0.0.0.3)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

However, according to this theory, persons with normal or acceptable faces should be singularly free from all psychological handicaps. They should be cheerful, happy, self-confident, free from anxiety and worry. We know only too well this is not true.

  

February 18, 2022

[31](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA31.w.0.0.0.4)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

When this self-image is intact and secure, you feel good. When it is threatened, you feel anxious and insecure. When your self-image is adequate and one that you can be wholesomely proud of, you feel self-confident. You feel free to “be yourself” and to express yourself.

  

February 18, 2022

[33](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA33.w.0.0.0.1)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

When it is an object of shame, you attempt to hide it rather than express it. Creative expression is blocked. You become hostile and hard to get along with.

  

February 18, 2022

[33](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA33.w.0.0.0.2)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

that you do not have to do the job alone. There is within each one of us a “life instinct,” which is forever working toward health, happiness, and all that makes for more life for the individual. This “life instinct” works for you through what I call the “Creative Mechanism” or, when used correctly, the “Success Mechanism” built into each human being.

  

February 18, 2022

[35](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA35)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

his Creative Mechanism within you is impersonal. It will work automatically and                                          impersonally to achieve goals of success and happiness, or unhappiness and failure, depending on the goals that you yourself set for it. Present it with “[[success Goals]],” and it functions as a Success Mechanism. Present it with negative goals, and it operates just as impersonally, and just as faithfully, as a Failure Mechanism.

  

February 18, 2022

[35](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA35.w.0.0.0.4)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

Like any other servo-mechanism, our Creative Mechanism works on information and data that we feed into it (our thoughts, beliefs, interpretations). Through our attitudes and interpretations of situations, we “describe” the problem to be worked on.

  

February 18, 2022

[36](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA36.w.0.0.0.3)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

Like any other servo-mechanism, our Creative Mechanism makes use of stored information, or                                          “memory,” in solving current problems and responding to current situations.

  

February 18, 2022

[36](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA36.w.0.0.0.4)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

Learning something about this Creative Mechanism, or automatic guidance system within you and how to use it as a Success Mechanism, rather than as a Failure Mechanism. The method itself consists in learning, practicing, and experiencing new habits of thinking, imagining, remembering, and acting in order to (1) develop an adequate and realistic self-image, and (2) use your Creative Mechanism to bring success and happiness in achieving particular goals.

  

February 18, 2022

[37](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA37)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

In order to direct your servo-mechanism toward success instead of failure, all you need is one experience that made you feel good about yourself. Remembering and then using that modest accomplishment will be instrumental in improving your self-image. You do not need a huge success experience to alter your self-image for the better. You do not need an experience that is a mirror of what you’re trying to create or accomplish. All you need is an experience like tying your shoe or learning to write your name for the first time, wherein you can say, “Yes, I’m glad I learned that skill. Yes, I remember the first day I could do it. Yes, I was happy.” This one memory, this one positive experience, no matter how long ago it took place, is all you need to begin changing the course of your life in the present.

  

February 18, 2022

[37](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA37.w.0.0.0.4)

  

  
  

  

![](https://lh4.googleusercontent.com/7W83ccovlNC_X2Eg5QSBD8ADblTun5EhS2RYWon9wso-W4cf2JiIrC70rqMTNgybsHehcuIRqBa00jOnJAiiGXJxpQE2LnxcGk886DXdHlVp6tlgGXlODI9op85Jc9kLtQOu52Bj)

YOUR CASE HISTORY List here an experience from your past that is explained by the principles given in this chapter:

  

February 18, 2022

[38](http://play.google.com/books/reader?printsec=frontcover&output=reader&id=SK8ILQAAAEAJ&source=books-notes-export&pg=GBS.PA38.w.0.0.0.1)

  

  
  
**